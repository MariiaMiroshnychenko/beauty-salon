package controller.command.impl;

import controller.command.Command;
import model.dto.RecordWithStatus;
import model.entity.Record;
import model.entity.Schedule;
import model.entity.User;
import model.services.RecordService;
import model.services.ScheduleService;
import model.services.UserService;
import model.services.impl.RecordServiceImpl;
import model.services.impl.ScheduleServiceImpl;
import model.services.impl.UserServiceImpl;
import sun.util.resources.cldr.ur.LocaleNames_ur;
import sun.util.resources.uk.LocaleNames_uk;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

public class ClientAppointment implements Command {
    private String[] hasAuthority = {"client"};

    @Override
    public String execute(HttpServletRequest request) {
        LocalDate date = LocalDate.parse(request.getParameter("visitDate"));
        User client = (User) request.getSession().getAttribute("user");

        ScheduleService scheduleService = new ScheduleServiceImpl();
        RecordService recordService = new RecordServiceImpl();
        UserService userService = new UserServiceImpl();

        if (Objects.nonNull(date)) {
            List<Schedule> schedules = scheduleService.findMastersByDay(date);
            List<User> masters = new ArrayList<>();

            schedules.forEach(schedule -> masters.add(userService.findUserById(schedule.getMasterId())));


            Map<LocalTime, String> statusMap = recordStatus();
//            masters.forEach(master -> master.getRecords().forEach(record -> statusMap.replace(record.getTime(), "record.status.disable")));

            System.out.println(recordStatus().keySet());
            System.out.println(recordStatus().values());
            request.setAttribute("masterList", masters);
            request.setAttribute("recordStatus", statusMap.values());
            request.setAttribute("time", recordStatus().keySet());
            request.getSession().setAttribute("selectedDate", request.getAttribute("visitDate"));
        }
        
        return "/WEB-INF/view/client-appointment.jsp";
    }

    @Override
    public boolean checkAuthority(String role) {
        return Arrays.asList(hasAuthority).contains(role);
    }

    private Map<LocalTime, String> recordStatus() {
        Map<LocalTime, String> status = new TreeMap<>();

        int beginHour = 10;
        int endHour = 19;
        int minute = 0;

        while (beginHour != endHour) {
            status.putIfAbsent(LocalTime.of(beginHour, minute), "record.status.able");
            beginHour++;
        }

        return status;
    }
}