package controller.command.impl;

import controller.command.Command;
import model.entity.Schedule;
import model.entity.User;
import model.services.RecordService;
import model.services.ScheduleService;
import model.services.UserService;
import model.services.impl.RecordServiceImpl;
import model.services.impl.ScheduleServiceImpl;
import model.services.impl.UserServiceImpl;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class ClientPage implements Command {
    private String[] hasAuthority = {"client"};

    @Override
    public String execute(HttpServletRequest request) {
        return "/WEB-INF/view/clientPage.jsp";
    }

    @Override
    public boolean checkAuthority(String role) {
        return Arrays.asList(hasAuthority).contains(role);
    }
}