package model.dao;

import model.entity.Procedure;

public interface ProcedureDao extends GenericDao<Procedure> {
}
