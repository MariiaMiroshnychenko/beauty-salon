package model.dao;

import model.entity.Record;

import java.util.List;

public interface RecordDao extends GenericDao<Record> {
    List<Record> findRecordsByMasterId(Integer masterId);
}
