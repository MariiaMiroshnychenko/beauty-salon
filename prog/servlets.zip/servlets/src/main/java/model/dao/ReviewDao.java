package model.dao;

import model.entity.Review;

public interface ReviewDao extends GenericDao<Review> {
}
