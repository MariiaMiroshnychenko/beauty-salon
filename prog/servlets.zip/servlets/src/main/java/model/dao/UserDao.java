package model.dao;

import model.entity.User;

public interface UserDao extends GenericDao<User> {
    User findUserByUsername(String username);
    User findUserById(Integer userId);
}
