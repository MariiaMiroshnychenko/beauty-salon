package model.dao.impl;

import model.dao.LanguageDao;
import model.entity.Language;

import java.sql.Connection;

public class LanguageJdbcDao implements LanguageDao {
    private Connection connection;

    public LanguageJdbcDao(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void create(Language language) {

    }

    @Override
    public void update(Language language) {

    }

    @Override
    public void delete() {

    }

    @Override
    public void close() {

    }
}
