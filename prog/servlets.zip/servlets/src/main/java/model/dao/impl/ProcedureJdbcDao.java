package model.dao.impl;

import model.dao.LanguageDao;
import model.dao.ProcedureDao;
import model.entity.Language;
import model.entity.Procedure;

import java.sql.Connection;

public class ProcedureJdbcDao implements ProcedureDao {
    private Connection connection;

    public ProcedureJdbcDao(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void create(Procedure procedure) {

    }

    @Override
    public void update(Procedure procedure) {

    }

    @Override
    public void delete() {

    }

    @Override
    public void close() {

    }
}
