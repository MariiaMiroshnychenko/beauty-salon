package model.dao.impl;

import model.dao.RecordDao;
import model.entity.Record;
import model.entity.User;
import model.mapper.impl.RecordMapper;
import model.mapper.impl.UserMapper;

import java.sql.*;
import java.sql.Date;
import java.util.*;

public class RecordJdbcDao implements RecordDao {
    private RecordMapper recordMapper = new RecordMapper();
    private Map<Integer, Record> recordMap = new HashMap<>();
    private Connection connection;

    public RecordJdbcDao(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void create(Record record) {
        try (PreparedStatement statement = connection.prepareStatement("insert into record (master_id, procedure_id, `date`, `time`, client_id) values (?, ?, ?, ?, ?)")) {
            statement.setInt(1, record.getMasterId());
            statement.setInt(2, record.getProcedureId());
            statement.setDate(3, Date.valueOf(record.getDate()));
            statement.setTime(4, Time.valueOf(record.getTime()));
            statement.setInt(5, record.getClientId());

            statement.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Record record) {

    }

    @Override
    public void delete() {

    }

    @Override
    public void close(){
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Record> findRecordsByMasterId(Integer masterId) {
        List<Record> records = new ArrayList<>();

        try (PreparedStatement statement = connection.prepareStatement("select * from record where master_id=?")) {
            statement.setInt(1, masterId);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Record record = recordMapper.extractFromResultSet(resultSet);

                recordMapper.makeUnique(recordMap, record);
            }
            resultSet.close();
            records = new ArrayList<>(recordMap.values());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return records;
    }
}
