package model.dao.impl;

import model.dao.ReviewDao;
import model.entity.Review;

import java.sql.Connection;

public class ReviewJdbcDao implements ReviewDao {
    private Connection connection;

    public ReviewJdbcDao(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void create(Review review) {

    }

    @Override
    public void update(Review review) {

    }

    @Override
    public void delete() {

    }

    @Override
    public void close() {

    }
}
