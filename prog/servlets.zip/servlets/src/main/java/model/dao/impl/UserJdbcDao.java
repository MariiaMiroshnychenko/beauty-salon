package model.dao.impl;

import model.dao.UserDao;
import model.entity.User;
import model.mapper.impl.UserMapper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class UserJdbcDao implements UserDao {
    private UserMapper userMapper = new UserMapper();
    private Map<Integer, User> userMap = new HashMap<>();
    private Connection connection;

    public UserJdbcDao(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void create(User user) {

    }

    @Override
    public void update(User user) {

    }

    @Override
    public void delete() {

    }

    @Override
    public void close() {
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public User findUserByUsername(String username) {
        User user = null;

        try (PreparedStatement statement = connection.prepareStatement("select * from `user` where username=?")) {
            statement.setString(1, username);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                user = userMapper.extractFromResultSet(resultSet);
            }
            if (Objects.nonNull(user)) {
                userMapper.makeUnique(userMap, user);
            }
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

    @Override
    public User findUserById(Integer userId) {
        User user = null;

        try (PreparedStatement statement = connection.prepareStatement("select * from `user` where id=?")) {
            statement.setInt(1, userId);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                user = userMapper.extractFromResultSet(resultSet);
            }
            if (Objects.nonNull(user)) {
                userMapper.makeUnique(userMap, user);
            }
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }
}
