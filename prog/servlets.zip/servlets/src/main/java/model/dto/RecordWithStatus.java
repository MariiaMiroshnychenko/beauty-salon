package model.dto;

import model.entity.Record;
import model.entity.User;

import java.util.List;

public class RecordWithStatus {
    private List<Record> records;
    private List<String> status;

    public RecordWithStatus(List<Record> records, List<String> status) {
        this.records = records;
        this.status = status;
    }

    public RecordWithStatus() {
    }

    public List<Record> getRecords() {
        return records;
    }

    public void setRecords(List<Record> records) {
        this.records = records;
    }

    public List<String> getStatus() {
        return status;
    }

    public void setStatus(List<String> status) {
        this.status = status;
    }
}
