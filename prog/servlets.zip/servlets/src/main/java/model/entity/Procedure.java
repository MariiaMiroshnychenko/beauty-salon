package model.entity;

import java.util.Objects;

public class Procedure {
    private Integer id;
    private String name;
    private Integer languageId;

    private Language language;

    public Procedure(Integer id, String name, Integer languageId, Language language) {
        this.id = id;
        this.name = name;
        this.languageId = languageId;
        this.language = language;
    }

    public Procedure(Integer id, String name, Integer languageId) {
        this.id = id;
        this.name = name;
        this.languageId = languageId;
    }

    public Procedure(String name, Integer languageId) {
        this.name = name;
        this.languageId = languageId;
    }

    public Procedure() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getLanguageId() {
        return languageId;
    }

    public void setLanguageId(Integer languageId) {
        this.languageId = languageId;
    }

    public Language getLanguage() {
        return language;
    }

    public void setLanguage(Language language) {
        this.language = language;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Procedure procedure = (Procedure) o;
        return Objects.equals(id, procedure.id) &&
                Objects.equals(name, procedure.name) &&
                Objects.equals(languageId, procedure.languageId) &&
                Objects.equals(language, procedure.language);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, languageId, language);
    }
}
