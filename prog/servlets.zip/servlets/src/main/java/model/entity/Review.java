package model.entity;

import java.time.LocalDateTime;
import java.util.Objects;

public class Review {
    private Integer id;
    private Integer clientId;
    private Integer masterId;
    private Integer procedureId;
    private String text;
    private LocalDateTime dateTime;

    private User client;
    private User master;
    private Procedure procedure;

    public Review(Integer id, Integer clientId, Integer masterId,
                  Integer procedureId, String text, LocalDateTime dateTime,
                  User client, User master, Procedure procedure) {
        this.id = id;
        this.clientId = clientId;
        this.masterId = masterId;
        this.procedureId = procedureId;
        this.text = text;
        this.dateTime = dateTime;
        this.client = client;
        this.master = master;
        this.procedure = procedure;
    }

    public Review(Integer id, Integer clientId, Integer masterId,
                  Integer procedureId, String text, LocalDateTime dateTime) {
        this.id = id;
        this.clientId = clientId;
        this.masterId = masterId;
        this.procedureId = procedureId;
        this.text = text;
        this.dateTime = dateTime;
    }

    public Review() {
    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public Integer getMasterId() {
        return masterId;
    }

    public void setMasterId(Integer masterId) {
        this.masterId = masterId;
    }

    public Integer getProcedureId() {
        return procedureId;
    }

    public void setProcedureId(Integer procedureId) {
        this.procedureId = procedureId;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Review review = (Review) o;
        return Objects.equals(id, review.id) &&
                Objects.equals(clientId, review.clientId) &&
                Objects.equals(masterId, review.masterId) &&
                Objects.equals(procedureId, review.procedureId) &&
                Objects.equals(text, review.text) &&
                Objects.equals(dateTime, review.dateTime) &&
                Objects.equals(client, review.client) &&
                Objects.equals(master, review.master) &&
                Objects.equals(procedure, review.procedure);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, clientId, masterId, procedureId, text, dateTime, client, master, procedure);
    }
}
