package model.services;

import model.entity.Record;

import java.util.List;

public interface RecordService {
    List<Record> findRecordsByMasterId(Integer masterId);
    void create(Record record);
}
