package model.services;

import model.entity.User;

public interface UserService {
    User findUserByUsername(String username);
    User findUserById(Integer userId);
}
