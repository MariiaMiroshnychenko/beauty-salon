package model.services.impl;

import model.dao.FactoryDao;
import model.dao.RecordDao;
import model.entity.Record;
import model.services.RecordService;

import java.util.List;

public class RecordServiceImpl implements RecordService {
    @Override
    public void create(Record record) {
        RecordDao recordDao = FactoryDao.getInstance().recordDao();

        recordDao.create(record);
        recordDao.close();
    }

    @Override
    public List<Record> findRecordsByMasterId(Integer masterId) {
        RecordDao recordDao = FactoryDao.getInstance().recordDao();
        List<Record> records = recordDao.findRecordsByMasterId(masterId);

        recordDao.close();
        return records;
    }
}
