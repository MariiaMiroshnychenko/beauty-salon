package model.services.impl;

import model.dao.FactoryDao;
import model.dao.UserDao;
import model.entity.User;
import model.services.UserService;

public class UserServiceImpl implements UserService {
    @Override
    public User findUserByUsername(String username) {
        UserDao userDao = FactoryDao.getInstance().userDao();
        User user = userDao.findUserByUsername(username);
        userDao.close();
        return user;
    }

    @Override
    public User findUserById(Integer userId) {
        UserDao userDao = FactoryDao.getInstance().userDao();
        User user = userDao.findUserById(userId);
        userDao.close();
        return user;
    }
}
